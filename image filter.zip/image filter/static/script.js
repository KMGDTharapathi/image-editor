function updateLabel(id, value) {
  document.getElementById(id).innerText = value;
}
